﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginNew
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }

        public object SQLCommand { get; private set; }
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Aysen\Source\Repos\LoginNew\LoginNew\testlogin.mdf;Integrated Security=True;Connect Timeout=30");
        private void button1_Click(object sender, EventArgs e)
        {
            string ins = "Insert into[login](username, password, name, efternamn, email, telefon)values('"+textBox1.Text+"', '"+textBox2.Text+"', '"+textBox3.Text+"' , '"+textBox4.Text+"', '"+textBox5.Text+"' , '"+textBox6.Text+"' )";
            SqlCommand con = new SqlCommand(ins, conn);
            conn.Open();
            con.ExecuteNonQuery();
            conn.Close();

            Hide();
            Login form = new Login();
            form.Show();

        }
    }
}
